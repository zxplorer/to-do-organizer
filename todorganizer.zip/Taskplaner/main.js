var pieChart;
var barChart;

var GetInputValue = function(id){
    var element = document.getElementById(id);
    return element.value;
}

var GetCategory = function(){
    var element = document.getElementById("category");
    return element.options[element.selectedIndex].text;
}

var GetTableRow= function(task, time, category){
    var tableRow = '<tr> ';
        tableRow += '<td> ' + task + '</td>';
        tableRow += '<td> ' + time + '</td>';
        tableRow += '<td> ' + category + '</td>';
        tableRow += '</tr>';
    return tableRow;
}

var checkIfInputFieldsEmpty = function(task, time, category){
    if(task === "" || time === "" || category === "-"){
        return false;
    }
    else {
        return true;
    }
}

var setCookie = function(task, time, category){
    var a = new Date();
    a = new Date(a.getTime() + 1000*60*60*24*365);
    var cookieString = task + "." + time + "." + category + "; expires="+ a.toGMTString()+';'; 
    if(document.cookie.length > 0) {
        document.cookie += '|'
    }
    document.cookie += cookieString;
}

var whichBrowserIsUsed = function(){
        //Detecting browsers by ducktyping

        // Firefox 1.0+
        var isFirefox = typeof InstallTrigger !== 'undefined';

        // Internet Explorer 6-11
        var isIE = /*@cc_on!@*/false || !!document.documentMode;

        // Edge 20+
        var isEdge = !isIE && !!window.StyleMedia;

        // Chrome 1 - 71
        var isChrome = !!window.chrome && (!!window.chrome.webstore || !!window.chrome.runtime);

        var result = new Array(isFirefox, isIE, isEdge, isChrome);

        return result;
}


var FillTableWithData = function(task, time, category, isCallByCookie){
    var table = document.getElementById("tblTasks");
    var row = table.insertRow(1);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    cell1.innerHTML = task;
    cell2.innerHTML = time;
    cell3.innerHTML = category;

    if(isCallByCookie === true){
        return;
    }

    setCookie(task , time, category);
}

var showToast = function(){
    var x = document.getElementById("snackbar");
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}




var IsInternetExplorerUsed = function(){
    var array = new Array();
    array = whichBrowserIsUsed();

    if (array[1]) {
        return true;
    } else {
        return false;
    }
}

var getDataFromCookie = function(cookie){
    
    var cookieStrings = cookie.split("|");
    for(var i = 0; i < cookieStrings.length; i++){
        var cookieArray = cookieStrings[i].split(".");
        if(cookieArray.length === 3) {
            FillTableWithData(cookieArray[0], cookieArray[1], cookieArray[2], true);
        }
    }
}

var activatePieChart = function(){
    if(pieChart != undefined){
        pieChart.destroy();
    }
    var percent = getCategorysPercent()
    showPieChart(percent);
}

var activateBarChart = function(){
    if(barChart != undefined){
        barChart.destroy();
    }
    var dates = xFactor();
    showBarChart(dates);
}

showPieChart = function(data, options) {

    var ctx = document.getElementById("pieChart");

    pieChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Schule', 'Arbeit', 'Privat'],
            datasets: [{
                data: data,
                backgroundColor: [
                    'rgb(255, 99, 132)',
                    'rgb(54, 162, 235)',
                    'rgb(255, 206, 86)',
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: false,
            maintainAspectRatio: false
          }
    });
}

var showBarChart = function(dates, data, options){

    var ctx = document.getElementById("barChart");

    barChart = new Chart(ctx, {
        type: 'bar',        
        data: {
            datasets: dates.map(d => {
                return {
                    label: d.date,
                    data: [d.value],
                    backgroundColor: "#"+((1<<24)*Math.random()|0).toString(16)
                }
            })
        },
        options: {
            responsive: false,
            maintainAspectRatio: false,
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true
                    }
                }]
            }
        }
    });

}

var buttonPressed = function(){
    var task = GetInputValue("taskInput");
    var time = GetInputValue("datepicker");
    var category = GetCategory();

    if(checkIfInputFieldsEmpty(task, time, category) === false){
        showToast();
    }
    else{
        FillTableWithData(task, time, category, false);
        activateBarChart();
        activatePieChart();
    }
}

var getCategorysPercent = function(){
    var elements = Array.from(
        document.querySelectorAll('tr > td:nth-child(3)'))
    
    var categories = elements.map(function (el) {
        return el.innerText;
    });

    var school = categories.filter(function(category) {
        return category.toLowerCase() === 'schule';
    })

    var work = categories.filter(function(category) {
        return category.toLowerCase() === 'arbeit';
    })

    var private = categories.filter(function(category) {
        return category.toLowerCase() === 'privat';
    })

    return [(school.length / categories.length * 100).toFixed(2),(work.length / categories.length * 100).toFixed(2), (private.length / categories.length * 100).toFixed(2)]
}

var xFactor = function() {
    var elements = Array.from(
        document.querySelectorAll('tr > td:nth-child(2)'))

    var dates = [];
    elements.forEach(s => {
        dates.push(convertDateString(s.innerText));
    });
    
    var distinctDates = dates.filter((function(){
        var returndValues = [];
        return (x) => {
            var foundElements = returndValues.some(function (item) {
                return  item.getTime() == x.getTime();
            });
            if(foundElements == false){
                returndValues.push(x);
                return true;
            }else{
                return false;
            }
        };
    })());

    dates.sort(function(a,b){
        return b - a;
      }).reverse();

      return distinctDates.map((d) => {
            return { 
                date: d.toISOString().slice(0,10),
                value: countTasks(d, dates)
            };
      });
}

var countTasks = function(taskDate, dates){
    var count = 0;
    dates.forEach(date => {
        if(taskDate.getTime() === date.getTime()){
            count++;
        }
    })

    console.log(count);
    return count;    
}

var convertDateString = function(dateString) {
    var date = new Date( Date.parse(dateString) );
    console.log(date.toLocaleDateString());
    return date;
}



var onLoad = function(){
    if(IsInternetExplorerUsed() === true){
        var picker = new Pikaday({ field: document.getElementById('datepicker') });
    }
    var cookie = document.cookie;
    if(cookie === ""){

    }
    else{
       getDataFromCookie(cookie);
    }
    activatePieChart();
    activateBarChart();
}


